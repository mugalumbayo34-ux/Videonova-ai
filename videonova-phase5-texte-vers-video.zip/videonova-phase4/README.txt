VIDÉONOVA AI — PHASE 4 : CONNECTEUR DE GÉNÉRATION VIDÉO IA

Cette version ajoute une première intégration serveur pour transformer une photo en vidéo IA via fal.ai / Kling 2.6 Pro. Il s'agit d'un socle technique : la génération réelle ne fonctionne qu'après installation, configuration d'une clé API valide et disponibilité du modèle chez le fournisseur. Des frais d'API peuvent s'appliquer.

PRÉREQUIS
- Node.js 20 ou plus récent
- Une clé API fal.ai et un compte fournisseur configuré : https://fal.ai
- Connexion Internet

DÉMARRAGE SUR UN ORDINATEUR
1. Décompresse le ZIP dans un dossier.
2. Ouvre un terminal dans ce dossier.
3. Copie .env.example vers .env.
4. Ouvre .env et remplace la valeur de FAL_KEY par ta clé secrète fal.ai.
5. Exécute : npm install
6. Exécute : npm start
7. Ouvre http://localhost:3000 dans le navigateur.
8. Dans « Anime une photo », ajoute une image, décris le mouvement, puis clique sur « Générer une vraie vidéo IA ».

IMPORTANT
- Ne partage jamais la clé FAL_KEY et ne la colle pas dans le HTML.
- Ce prototype n'a pas encore de comptes, de base de données, de quota gratuit sécurisé ni de paiement PayPal.
- Il ne faut pas le publier directement en production sans authentification, limites de débit, contrôle des coûts, règles de confidentialité, stockage vidéo durable et protection contre les abus.
- Le fournisseur peut modifier ses modèles, paramètres, disponibilité, tarifs et durée de conservation des URL. Vérifie sa documentation officielle avant un lancement public.
- L'export local de montage reste en WebM. La génération IA renvoie un lien vidéo du fournisseur ; le lien peut être temporaire.

DOCUMENTATION OFFICIELLE
fal.ai : https://fal.ai/models/fal-ai/kling-video/v2.6/pro/image-to-video/api
Client JS : https://fal.ai/docs


PHASE 5 — TEXTE → VIDÉO IA
-------------------------
Cette version ajoute un bouton de génération vidéo à partir d'une description textuelle.
Le serveur appelle fal.ai avec le modèle Kling 2.6 Pro text-to-video. Le modèle/endpoint et les champs acceptés peuvent évoluer : consulte la documentation fal.ai si l'API renvoie une erreur.

Pour tester : configure FAL_KEY dans .env côté serveur, lance npm install puis npm start. Ouvre http://localhost:3000, choisis « Texte → vidéo », saisis une idée et appuie sur « Générer une vraie vidéo depuis le texte ».
La clé API ne doit jamais être placée dans index.html ni partagée. Les générations peuvent être payantes; vérifie les tarifs et les limites du fournisseur avant de tester. Les liens vidéo retournés peuvent être temporaires.
Cette version n'inclut toujours pas de comptes utilisateurs, de quota gratuit sécurisé ou de paiement PayPal.
