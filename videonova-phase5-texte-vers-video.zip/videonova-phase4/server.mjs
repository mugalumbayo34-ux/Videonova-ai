import express from 'express';
import multer from 'multer';
import dotenv from 'dotenv';
import { fal } from '@fal-ai/client';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3000);
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024 }, fileFilter: (_req, file, cb) => {
  if (!file.mimetype?.startsWith('image/')) return cb(new Error('Le fichier doit être une image.'));
  cb(null, true);
}});

if (process.env.FAL_KEY) fal.config({ credentials: process.env.FAL_KEY });

app.use(express.static(__dirname));
app.get('/api/health', (_req, res) => res.json({ ok: true, providerConfigured: Boolean(process.env.FAL_KEY) }));
app.use(express.json({ limit: '20kb' }));
app.post('/api/generate-text-video', async (req, res) => {
  try {
    if (!process.env.FAL_KEY) return res.status(503).json({ error: 'Le serveur n’a pas encore de clé FAL_KEY. Configure .env puis redémarre le serveur.' });
    const prompt = String(req.body?.prompt || '').trim().slice(0, 1200);
    if (prompt.length < 5) return res.status(400).json({ error: 'Décris la vidéo en au moins 5 caractères.' });
    const aspectRatio = ['9:16', '1:1', '16:9'].includes(req.body?.aspectRatio) ? req.body.aspectRatio : '9:16';
    const result = await fal.subscribe('fal-ai/kling-video/v2.6/pro/text-to-video', {
      input: { prompt, duration: '5', aspect_ratio: aspectRatio },
      logs: false
    });
    const videoUrl = result?.data?.video?.url || result?.video?.url || (Array.isArray(result?.data?.videos) ? result.data.videos[0]?.url : null);
    if (!videoUrl) return res.status(502).json({ error: 'Le fournisseur n’a pas renvoyé de lien vidéo. Vérifie que le modèle texte→vidéo est disponible sur ton compte fal.ai.' });
    res.json({ videoUrl, provider: 'fal.ai', model: 'Kling 2.6 Pro Text-to-Video', note: 'Le lien du fichier généré peut être temporaire.' });
  } catch (error) {
    console.error('Text-to-video AI error:', error?.message || error);
    res.status(500).json({ error: error?.message || 'Erreur pendant la génération vidéo depuis le texte.' });
  }
});

app.post('/api/generate-video', upload.single('image'), async (req, res) => {
  try {
    if (!process.env.FAL_KEY) return res.status(503).json({ error: 'Le serveur n’a pas encore de clé FAL_KEY. Configure le fichier .env puis redémarre le serveur.' });
    if (!req.file) return res.status(400).json({ error: 'Ajoute une image valide.' });
    const prompt = String(req.body.prompt || '').trim().slice(0, 1200);
    if (prompt.length < 5) return res.status(400).json({ error: 'Décris la vidéo en au moins 5 caractères.' });
    // The secret key stays server-side. Upload the image through fal's storage service.
    const imageFile = new File([req.file.buffer], req.file.originalname || 'upload.jpg', { type: req.file.mimetype });
    const imageUrl = await fal.storage.upload(imageFile);
    const result = await fal.subscribe('fal-ai/kling-video/v2.6/pro/image-to-video', {
      input: {
        prompt,
        image_url: imageUrl,
        duration: '5',
        aspect_ratio: ['9:16', '1:1', '16:9'].includes(req.body.aspectRatio) ? req.body.aspectRatio : '9:16'
      },
      logs: false
    });
    const videoUrl = result?.data?.video?.url || result?.video?.url || (Array.isArray(result?.data?.videos) ? result.data.videos[0]?.url : null);
    if (!videoUrl) return res.status(502).json({ error: 'Le fournisseur n’a pas renvoyé de lien vidéo. Vérifie les paramètres du modèle dans la documentation fal.ai.' });
    res.json({ videoUrl, provider: 'fal.ai', model: 'Kling 2.6 Pro', note: 'Le lien du fichier généré peut être temporaire.' });
  } catch (error) {
    console.error('AI generation error:', error?.message || error);
    res.status(500).json({ error: error?.message || 'Erreur pendant la génération vidéo.' });
  }
});
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'Image trop grande : maximum 12 Mo.' });
  res.status(400).json({ error: err.message || 'Requête invalide.' });
});
app.listen(port, () => console.log(`VidéoNova AI ouvert sur http://localhost:${port}`));
